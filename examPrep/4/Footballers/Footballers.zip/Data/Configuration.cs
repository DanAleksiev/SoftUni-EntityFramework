﻿namespace Footballers.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=MSI\SQLEXPRESS;Database=FootballersExamPrep;Integrated Security=True;MultipleActiveResultSets=true;Encrypt=False";
    }
}
