﻿namespace Footballers.Data.Models.Enums
    {
    public enum Position
        {
        Goalkeeper,
        Defender,
        Midfielder,
        Forward
        }
    }