﻿namespace Footballers.Data.Models.Enums
    {
    public enum BestSkill
        {
        Defence,
        Dribble,
        Pass,
        Shoot,
        Speed
        }
    }