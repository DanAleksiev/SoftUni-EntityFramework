﻿namespace Invoices.Data.Models.Enums
    {
    public enum CategoryTypesEnum
        {
        ADR,
        Filters,
        Lights,
        Others,
        Tyres
        }
    }
