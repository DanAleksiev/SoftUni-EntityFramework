﻿namespace Invoices.Data.Models.Enums
    {
    public enum CurrencyTypeEnum
        {
        BGN,
        EUR,
        USD
        }
    }
