﻿namespace Invoices.Data.Models.Enums
    {
    public enum CurrencyType
        {
        BGN,
        EUR,
        USD
        }
    }
