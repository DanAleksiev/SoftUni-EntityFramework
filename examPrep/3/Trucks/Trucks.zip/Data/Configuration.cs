﻿namespace Trucks.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=MSI\SQLEXPRESS;Database=CarDealerXlm;Integrated Security=True;MultipleActiveResultSets=true;Encrypt=False";
        }
}