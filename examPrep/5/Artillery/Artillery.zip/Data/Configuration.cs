﻿namespace Artillery.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=MSI\SQLEXPRESS;Database=Artillery;Integrated Security=True;Encrypt=False";
    }
}
