﻿namespace Artillery.DataProcessor.ImportDto
    {
    public class ImportManufacturersDTO
        {
        }
    }
