﻿
namespace P01_StudentSystem.Data.Models.Enums
    {
    public enum ResourceTypes
        {
        Video,
        Presentation,
        Document,
        other
        }
    }
