﻿namespace MusicHub.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=MSI\SQLEXPRESS;Database=MusicHub;Integrated Security=True;TrustServerCertificate=True";

        }
    }
