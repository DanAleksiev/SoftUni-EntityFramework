﻿namespace CarDealer.Data
{
    public static class Configuration
    {
        public const string ConnectionString =
            "Server=MSI\\SQLEXPRESS;Database=CarDealer;Integrated Security=True;MultipleActiveResultSets=true;Encrypt=False";
    }
}
