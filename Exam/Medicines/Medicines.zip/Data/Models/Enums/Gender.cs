﻿namespace Medicines.Data.Models.Enums
    {
    public enum Gender
        {
        male,
        female
        }
    }