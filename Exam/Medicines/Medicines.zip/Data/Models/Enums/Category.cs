﻿namespace Medicines.Data.Models.Enums
    {
    public enum Category
        {
        analgesic,
        antibiotic,
        antiseptic,
        sedative,
        vaccine

        }
    }