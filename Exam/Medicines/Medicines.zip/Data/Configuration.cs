﻿namespace Medicines.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=MSI\SQLEXPRESS;Database=Exam;Integrated Security=True;MultipleActiveResultSets=true;Encrypt=False";
        }
}
