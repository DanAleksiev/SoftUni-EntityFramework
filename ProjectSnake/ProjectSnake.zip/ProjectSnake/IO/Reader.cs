﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.PortableExecutable;
using System.Text;
using System.Threading.Tasks;

namespace ProjectSnake.IO
    {
    public class Reader
        {
        public string ReadLine()
            {
            return Console.ReadLine();
            }
        }
    }
