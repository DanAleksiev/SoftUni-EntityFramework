﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectSnake.IO
{
    public class Writer
        {
        public void Write(string message)
            {
            Console.Write(message);
            }

        public void WriteLine(string message)
            {
            Console.WriteLine(message);
            }
        }
    }
