﻿
namespace ProjectSnake
    {
    public enum GridValue
        {
            Empty,
            Snake,
            Food,
            Outside,
        }
    }
